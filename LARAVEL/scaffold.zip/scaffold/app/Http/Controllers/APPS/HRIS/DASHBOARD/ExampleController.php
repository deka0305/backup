<?php

namespace App\Http\Controllers\APPS\HRIS\DASHBOARD;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ExampleController extends Controller
{
    public function index(Request $request)
    {
        return 'hris dashboard home';
    }
}
