<div class="footer-left">
    Copyright &copy; <?php echo e(now()->year); ?> <div class="bullet"></div> Design By <a
    href="">DIT Departement</a> Laravel Code By <a href="">PT. Indotaichen Textile Industry</a>
</div>
<div class="footer-right">
    1.0.0
</div>
<?php /**PATH C:\laragon\www\laravel\scaffold\resources\views/layouts/footer.blade.php ENDPATH**/ ?>