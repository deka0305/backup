<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items List</title>
</head>
<body>
    <h1>Items List</h1>

    <!-- Search, Filter, and Sort Form -->
    <form method="GET" action="<?php echo e(route('items.index')); ?>">
        <input type="text" name="search" placeholder="Search" value="<?php echo e(request('search')); ?>">

        <select name="status">
            <option value="">All</option>
            <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
            <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
        </select>

        <select name="sort_by">
            <option value="name" <?php echo e(request('sort_by') == 'name' ? 'selected' : ''); ?>>Name</option>
            <option value="created_at" <?php echo e(request('sort_by') == 'created_at' ? 'selected' : ''); ?>>Created At</option>
        </select>

        <select name="sort_order">
            <option value="asc" <?php echo e(request('sort_order') == 'asc' ? 'selected' : ''); ?>>Ascending</option>
            <option value="desc" <?php echo e(request('sort_order') == 'desc' ? 'selected' : ''); ?>>Descending</option>
        </select>

        <button type="submit">Apply</button>
    </form>

    <!-- Display Paginated Results -->
    <table border="1" cellspacing="0" cellpadding="10">
        <thead>
            <tr>
                <th>TRANSACTION NUMBER</th>
                <th>CREATION DATETIME</th>
                <th>CREATION USER</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->transactionnumber); ?></td>
                    <td><?php echo e($item->creationdatetime); ?></td>
                    <td><?php echo e($item->creationuser); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Pagination Links -->
    <?php echo e($items->appends(request()->input())->links()); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\laravel\scaffold\resources\views/datatables.blade.php ENDPATH**/ ?>