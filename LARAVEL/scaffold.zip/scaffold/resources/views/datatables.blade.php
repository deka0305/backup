<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items List</title>
</head>
<body>
    <h1>Items List</h1>

    <!-- Search, Filter, and Sort Form -->
    <form method="GET" action="{{ route('items.index') }}">
        <input type="text" name="search" placeholder="Search" value="{{ request('search') }}">

        <select name="status">
            <option value="">All</option>
            <option value="active" {{ request('status') == 'active' ? 'selected' : '' }}>Active</option>
            <option value="inactive" {{ request('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>
        </select>

        <select name="sort_by">
            <option value="name" {{ request('sort_by') == 'name' ? 'selected' : '' }}>Name</option>
            <option value="created_at" {{ request('sort_by') == 'created_at' ? 'selected' : '' }}>Created At</option>
        </select>

        <select name="sort_order">
            <option value="asc" {{ request('sort_order') == 'asc' ? 'selected' : '' }}>Ascending</option>
            <option value="desc" {{ request('sort_order') == 'desc' ? 'selected' : '' }}>Descending</option>
        </select>

        <button type="submit">Apply</button>
    </form>

    <!-- Display Paginated Results -->
    <table border="1" cellspacing="0" cellpadding="10">
        <thead>
            <tr>
                <th>TRANSACTION NUMBER</th>
                <th>CREATION DATETIME</th>
                <th>CREATION USER</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
                <tr>
                    <td>{{ $item->transactionnumber }}</td>
                    <td>{{ $item->creationdatetime }}</td>
                    <td>{{ $item->creationuser }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Pagination Links -->
    {{ $items->appends(request()->input())->links() }}
</body>
</html>
