<div class="footer-left">
    Copyright &copy; {{ now()->year }} <div class="bullet"></div> Design By <a
    href="">DIT Departement</a> Laravel Code By <a href="">PT. Indotaichen Textile Industry</a>
</div>
<div class="footer-right">
    1.0.0
</div>
