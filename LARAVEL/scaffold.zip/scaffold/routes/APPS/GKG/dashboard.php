<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

Route::get('gkg-example', [\App\Http\Controllers\APPS\GKG\DASHBOARD\ExampleController::class, 'index'])
->name('gkg.example.dashboard.index');
