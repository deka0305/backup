<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

Route::get('home', [\App\Http\Controllers\APPS\HRIS\DASHBOARD\ExampleController::class, 'index'])
->name('hris.example.dashboard.index');
