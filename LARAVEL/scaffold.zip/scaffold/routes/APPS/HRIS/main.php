<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

Route::get('home', [\App\Http\Controllers\APPS\HRIS\MAIN\ExampleController::class, 'index'])
->name('hris.example.main.index');

Route::get('hari-libur', [\App\Http\Controllers\APPS\HRIS\MAIN\ExampleController::class, 'index'])
->name('hris.example.main.index');
