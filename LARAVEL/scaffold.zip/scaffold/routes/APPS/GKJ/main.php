<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

Route::get('gkj-example', [\App\Http\Controllers\APPS\GKJ\MAIN\ExampleController::class, 'index'])
->name('gkj.example.main.index');
