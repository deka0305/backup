<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

Route::get('gkj-example', [\App\Http\Controllers\APPS\GKJ\DASHBOARD\ExampleController::class, 'index'])
->name('gkj.example.dashboard.index');
