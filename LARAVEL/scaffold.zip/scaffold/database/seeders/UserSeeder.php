<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => "SuperAdmin",
            'email' => "superadmin@gmail.com",
            'password' => Hash::make('Sunkam@24809'),
            'email_verified_at' => now(),
        ]);
        
        User::create([
            'name' => "User",
            'email' => "user@gmail.com",
            'password' => Hash::make('4dm1n'),
            'email_verified_at' => now(),
        ]);
        // User::factory()->count(10)->create();
    }
}
