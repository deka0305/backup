## Cara Run K6

- k6 run filename.js