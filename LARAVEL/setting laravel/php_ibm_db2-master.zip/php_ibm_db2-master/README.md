# php_ibm_db2
This repository is for internal purpose only to maintain windows dlls for php db2 drivers(php_ibm_db2 driver and php_pdo_ibm driver). Please go to the below links for instructions to install php_ibm_db2 driver and php_pdo_ibm driver

 ibm_db2:
 <a name="ibm_db2"></a> [https://github.com/php/pecl-database-ibm_db2](https://github.com/php/pecl-database-ibm_db2)


 pdo_ibm:
 <a name="pdo_ibm"></a> [https://github.com/php/pecl-database-pdo_ibm](https://github.com/php/pecl-database-pdo_ibm)


